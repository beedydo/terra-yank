const { parseArn, slugify } = require("./utils");
const resourceMap = require("./resource-map.json");
const { DescribeSecurityGroupRulesCommand } = require("@aws-sdk/client-ec2");
const { getClients } = require("./awsClients");

function mapToTerraformImport(resource) {
  const parsed = parseArn(resource.arn);

  const specificKey = `${parsed.service}:${parsed.resourceType}`;
  let mapping = resourceMap.resources[specificKey];

  if (!mapping) mapping = resourceMap.resources[parsed.service];

  if (!mapping) return null;

  let importId;
  if (mapping.importIdTemplate) {
    importId = mapping.importIdTemplate
      .replace("${region}", parsed.region)
      .replace("${accountId}", parsed.accountId)
      .replace("${resourceId}", parsed.resourceId)
      .replace("${resourceRaw}", parsed.resourceRaw)
      .replace("${resourceType}", parsed.resourceType)
      .replace("${arn}", resource.arn);
  } else if (mapping.importIdField === "arn") importId = resource.arn;
  else if (mapping.importIdField === "resourceRaw") importId = parsed.resourceRaw;
  else importId = parsed.resourceId;

  return { tfType: mapping.tfType, importId };
}

function importSupport(resource) {
  const mapping = mapToTerraformImport(resource);
  if (!mapping) {
    return {
      importSupported: false,
      unsupportedReason: "No import mapping configured",
    };
  }
  return { importSupported: true, tfType: mapping.tfType, importId: mapping.importId };
}

async function resolveSecurityGroupRules(sgrIds, region, credentials) {
  if (!sgrIds.length || !region) return {};
  try {
    const { ec2 } = getClients(region, credentials);
    const resp = await ec2.send(new DescribeSecurityGroupRulesCommand({
      SecurityGroupRuleIds: sgrIds,
    }));
    const result = {};
    for (const rule of resp.SecurityGroupRules || []) {
      result[rule.SecurityGroupRuleId] = { isEgress: rule.IsEgress };
    }
    return result;
  } catch {
    return {};
  }
}

async function buildImportArtifact({ selection, region, account, credentials }) {
  const selectedResources = Array.isArray(selection) ? selection : [];
  const mappedResources = [];
  const unsupportedResources = [];

  selectedResources.forEach((resource, idx) => {
    const mapped = mapToTerraformImport(resource);
    if (!mapped) {
      unsupportedResources.push({
        arn: resource.arn,
        service: resource.service,
        resourceType: resource.resourceType,
        reason: "unsupported_resource_type_for_auto_mapping",
      });
      return;
    }

    const importProject = slugify(resource.category || resource.service || "default");
    mappedResources.push({
      ...resource,
      ...mapped,
      importProject,
      logicalName: `${mapped.tfType}_${slugify(resource.resourceType || resource.service)}_${idx + 1}`,
    });
  });

  const sgrResources = mappedResources.filter(
    (r) => r.tfType === "aws_vpc_security_group_ingress_rule" || r.tfType === "aws_vpc_security_group_egress_rule"
  );
  if (sgrResources.length) {
    const sgrIds = sgrResources.map((r) => r.importId);
    const resolved = await resolveSecurityGroupRules(sgrIds, region, credentials);
    for (const r of sgrResources) {
      const info = resolved[r.importId];
      if (info?.isEgress) {
        r.tfType = "aws_vpc_security_group_egress_rule";
        r.logicalName = r.logicalName.replace("aws_vpc_security_group_ingress_rule", "aws_vpc_security_group_egress_rule");
      }
    }
  }

  const byProject = {};
  for (const item of mappedResources) {
    if (!byProject[item.importProject]) byProject[item.importProject] = [];
    byProject[item.importProject].push(item);
  }

  const files = Object.entries(byProject).map(([project, resources]) => {
    const importsTf = resources.map((item) => [
      "import {",
      `  to = ${item.tfType}.${item.logicalName}`,
      `  id = "${item.importId}"`,
      "}",
      "",
      `resource "${item.tfType}" "${item.logicalName}" {`,
      "  # TODO: fill arguments after import and terraform plan review",
      "}",
      "",
    ].join("\n")).join("\n");

    return {
      project,
      importsPath: `${project}/imports.tf`,
      selectionPath: `${project}/selection.json`,
      importsTf,
      resources,
    };
  });

  return {
    generatedAt: new Date().toISOString(),
    region,
    account,
    totalSelected: selectedResources.length,
    terraformMappableCount: mappedResources.length,
    unsupportedCount: unsupportedResources.length,
    mappedResources,
    unsupportedResources,
    files,
    importsTf: files.map((file) => [`# Project: ${file.project}`, `# File: ${file.importsPath}`, file.importsTf].join("\n")).join("\n\n"),
  };
}

module.exports = {
  buildImportArtifact,
  importSupport,
  mapToTerraformImport,
};
