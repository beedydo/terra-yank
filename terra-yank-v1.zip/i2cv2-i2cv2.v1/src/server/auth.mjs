import { betterAuth } from "better-auth";
import { genericOAuth } from "better-auth/plugins";
import { LibsqlDialect } from "@libsql/kysely-libsql";

export const auth = betterAuth({
  database: {
    dialect: new LibsqlDialect({ url: "file:./i2cv2-auth.db" }),
    type: "sqlite",
  },
  basePath: "/api/auth",
  secret: process.env.BETTER_AUTH_SECRET,
  baseURL: process.env.BETTER_AUTH_URL,
  trustedOrigins: [process.env.BETTER_AUTH_URL],
  plugins: [
    genericOAuth({
      config: [
        {
          providerId: "techpass",
          clientId: process.env.TECHPASS_CLIENT_ID,
          clientSecret: process.env.TECHPASS_CLIENT_SECRET,
          discoveryUrl:
            "https://govauth.sandbox.gov.sg/.well-known/openid-configuration",
          scopes: ["openid", "profile", "email", "offline_access"],
          pkce: true,
        },
      ],
    }),
  ],
});
