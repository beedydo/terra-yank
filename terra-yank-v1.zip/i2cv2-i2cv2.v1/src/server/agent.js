const Anthropic = require("@anthropic-ai/sdk");
const fs = require("fs/promises");
const path = require("path");
const { readWorkspaceFiles, writeWorkspaceFiles, plan, initWorkspace } = require("./workspace");

const SYSTEM_PROMPT = `You are a Terraform expert refining auto-generated import configuration.

You will receive the current Terraform files in a workspace and the output of terraform plan.

Your task:
- Remove arguments that are set to their provider default or are computed/read-only values.
- Fix conflicting arguments — terraform plan -generate-config-out often emits mutually exclusive attributes together. When the plan output shows "conflicts with", keep the non-computed one and remove the other. Common examples:
  - aws_subnet: keep availability_zone, remove availability_zone_id (or vice versa)
  - aws_instance: keep subnet_id, remove availability_zone if both are set
- Remove attributes set to zero or empty when Terraform rejects them (e.g., enable_lni_at_device_index = 0).
- Remove attribute groups where not all required co-dependent attributes are present (e.g., map_customer_owned_ip_on_launch requires customer_owned_ipv4_pool and outpost_arn — remove all three unless all are meaningful).
- Group resources into files by service or domain (e.g., network.tf, compute.tf, storage.tf).
- Extract repeated values (AMI IDs, VPC IDs, subnet IDs, region) into variables.tf and provide defaults in terraform.tfvars.
- Keep the import blocks in imports.tf unchanged — do not modify resource addresses or import IDs.
- Do NOT add or remove resources. Only refine the existing ones.
- Do NOT modify main.tf (provider configuration).

Output format — return the complete contents of each .tf file you want to write or update:
### FILE: <filename>
<full file content>

Include every .tf file that should exist in the workspace (except main.tf and imports.tf).
Files you do not mention will be deleted.

Correctness rule:
After your changes, terraform plan must show ONLY import actions and no infrastructure changes.
If your previous changes caused drift or errors, the plan output below shows what went wrong — fix it.`;

function isSafeFilename(name) {
  return /^[a-zA-Z0-9_.-]+\.tf$/.test(name) && !name.includes("..");
}

function parseFileBlocks(text) {
  const files = {};
  const regex = /### FILE:\s*(\S+)\s*\n([\s\S]*?)(?=### FILE:|$)/g;
  let match;
  while ((match = regex.exec(text)) !== null) {
    const name = match[1].trim();
    const content = match[2].replace(/^```\w*\n?/, "").replace(/\n?```\s*$/, "").trimEnd() + "\n";
    if (name !== "main.tf" && name !== "imports.tf" && isSafeFilename(name)) {
      files[name] = content;
    }
  }
  return files;
}

function buildUserMessage(files, planOutput, iteration, customPrompt) {
  const fileSection = Object.entries(files)
    .filter(([name]) => name !== "main.tf" && name !== "imports.tf")
    .map(([name, content]) => `### FILE: ${name}\n${content}`)
    .join("\n\n");

  const prefix = iteration === 0
    ? "This is the initial generated configuration. Please refine it."
    : "Your previous changes caused issues. The plan output below shows what went wrong. Please fix it.";

  let msg = `${prefix}

Current Terraform files:

${fileSection}

Terraform plan output:

${planOutput}`;

  if (customPrompt) {
    msg += `\n\nAdditional instructions from the user:\n${customPrompt}`;
  }
  return msg;
}

async function applyLlmFiles(workspaceDir, newFiles, onProgress) {
  const allFiles = await readWorkspaceFiles(workspaceDir);
  const existingTfFiles = Object.keys(allFiles).filter((f) => f !== "main.tf" && f !== "imports.tf");
  const removed = [];
  for (const old of existingTfFiles) {
    if (!newFiles[old]) {
      await fs.unlink(path.join(workspaceDir, old));
      removed.push(old);
    }
  }
  if (removed.length && onProgress) {
    onProgress({ phase: "llm", message: `Removed ${removed.length} stale file(s): ${removed.join(", ")}` });
  }
  await writeWorkspaceFiles(workspaceDir, newFiles);
  const finalFiles = await readWorkspaceFiles(workspaceDir);
  return finalFiles;
}

async function runSingleRefinement({ workspaceDir, apiKey, baseURL, model, customPrompt, signal, onProgress }) {
  const client = new Anthropic({ apiKey, ...(baseURL && { baseURL }) });
  const modelId = model || "bedrock.claude-sonnet-4-6";
  const send = onProgress || (() => {});

  send({ phase: "llm", message: "Reading workspace files..." });
  const files = await readWorkspaceFiles(workspaceDir);

  send({ phase: "validate", message: "Running terraform plan to assess current state..." });
  if (signal?.aborted) throw Object.assign(new Error("Cancelled"), { isAbort: true });
  const planResult = await plan(workspaceDir, { signal });
  const planOutput = `${planResult.stdout}\n${planResult.stderr}`.trim();

  if (planResult.clean) {
    send({ phase: "done", message: "Plan is already clean — no refinement needed." });
    return { files, planOutput, clean: true, inputTokens: 0, outputTokens: 0 };
  }

  send({ phase: "llm", message: `Sending configuration to ${modelId}...` });
  const userMessage = buildUserMessage(files, planOutput, 0, customPrompt);

  let response;
  try {
    response = await client.messages.create({
      model: modelId,
      max_tokens: 16384,
      system: SYSTEM_PROMPT,
      messages: [{ role: "user", content: userMessage }],
    });
  } catch (err) {
    const detail = err.status ? `(HTTP ${err.status})` : "";
    send({ phase: "error", message: `LLM API error ${detail}: ${err.message}` });
    throw err;
  }

  const inputTokens = response.usage.input_tokens;
  const outputTokens = response.usage.output_tokens;
  send({ phase: "llm", message: `LLM responded (${(inputTokens + outputTokens).toLocaleString()} tokens). Parsing file changes...` });

  const assistantText = response.content.filter((b) => b.type === "text").map((b) => b.text).join("\n");
  const newFiles = parseFileBlocks(assistantText);
  const newFileNames = Object.keys(newFiles);

  if (newFileNames.length === 0) {
    send({ phase: "error", message: "LLM returned no parseable file blocks." });
    return { files, planOutput, clean: false, inputTokens, outputTokens };
  }

  send({ phase: "llm", message: `LLM produced ${newFileNames.length} file(s): ${newFileNames.join(", ")}. Writing to workspace...` });
  const updatedFiles = await applyLlmFiles(workspaceDir, newFiles, send);

  send({ phase: "validate", message: "Running terraform init -upgrade..." });
  if (signal?.aborted) throw Object.assign(new Error("Cancelled"), { isAbort: true });
  try { await initWorkspace(workspaceDir, { signal, upgrade: true }); } catch {}

  send({ phase: "validate", message: "Running terraform plan to validate changes..." });
  const validateResult = await plan(workspaceDir, { signal });
  const validateOutput = `${validateResult.stdout}\n${validateResult.stderr}`.trim();

  const summary = (validateResult.stdout || "").match(/Plan: .*/)?.[0] || (validateResult.clean ? "clean" : "changes pending");
  send({ phase: "done", message: `Refinement complete (${summary}).` });

  return { files: updatedFiles, planOutput: validateOutput, clean: validateResult.clean, inputTokens, outputTokens };
}

async function runAgentLoop({ workspaceDir, apiKey, baseURL, model, maxIterations, tokenBudget, signal, onProgress }) {
  const client = new Anthropic({ apiKey, ...(baseURL && { baseURL }) });
  const modelId = model || "bedrock.claude-sonnet-4-6";

  let totalInputTokens = 0;
  let totalOutputTokens = 0;
  let iteration = 0;

  const files = await readWorkspaceFiles(workspaceDir);
  const fileCount = Object.keys(files).length;
  onProgress({ phase: "llm", message: `Workspace has ${fileCount} file(s). Running initial terraform plan to check baseline...`, iteration: 0, tokensUsed: 0 });

  const initialPlan = await plan(workspaceDir, { signal });
  if (initialPlan.clean) {
    onProgress({ phase: "done", message: "Generated config already produces a clean plan — no LLM refinement needed.", iteration: 0, tokensUsed: 0 });
    return { files, iterations: 0, totalInputTokens: 0, totalOutputTokens: 0, clean: true };
  }

  const planIssues = (initialPlan.stdout || "").match(/Plan: .*/)?.[0] || "plan has pending changes";
  onProgress({ phase: "llm", message: `Baseline plan not clean (${planIssues}). Starting LLM refinement loop...`, iteration: 0, tokensUsed: 0 });

  let planOutput = `${initialPlan.stdout}\n${initialPlan.stderr}`.trim();
  let currentFiles = { ...files };

  while (iteration < maxIterations) {
    if (signal?.aborted) throw Object.assign(new Error("Cancelled"), { isAbort: true });

    const budgetUsed = totalInputTokens + totalOutputTokens;
    if (budgetUsed >= tokenBudget) {
      onProgress({ phase: "done", message: `Token budget exhausted (${budgetUsed.toLocaleString()} / ${tokenBudget.toLocaleString()} tokens used). Returning best result after ${iteration} iteration(s).`, iteration, tokensUsed: budgetUsed });
      return { files: currentFiles, iterations: iteration, totalInputTokens, totalOutputTokens, clean: false, reason: "budget_exceeded" };
    }

    const remainingBudget = tokenBudget - budgetUsed;
    onProgress({ phase: "llm", message: `Iteration ${iteration + 1}/${maxIterations}: Sending configuration to ${modelId} (${remainingBudget.toLocaleString()} tokens remaining)...`, iteration: iteration + 1, tokensUsed: budgetUsed });

    const userMessage = buildUserMessage(currentFiles, planOutput, iteration);

    let response;
    try {
      response = await client.messages.create({
        model: modelId,
        max_tokens: 16384,
        system: SYSTEM_PROMPT,
        messages: [{ role: "user", content: userMessage }],
      });
    } catch (err) {
      const detail = err.status ? `(HTTP ${err.status})` : "";
      onProgress({ phase: "error", message: `LLM API error ${detail}: ${err.message}`, iteration: iteration + 1, tokensUsed: budgetUsed });
      throw err;
    }

    totalInputTokens += response.usage.input_tokens;
    totalOutputTokens += response.usage.output_tokens;
    const roundTokens = response.usage.input_tokens + response.usage.output_tokens;

    onProgress({ phase: "llm", message: `Iteration ${iteration + 1}: LLM responded (${roundTokens.toLocaleString()} tokens this round). Parsing file changes...`, iteration: iteration + 1, tokensUsed: totalInputTokens + totalOutputTokens });

    const assistantText = response.content
      .filter((b) => b.type === "text")
      .map((b) => b.text)
      .join("\n");

    const newFiles = parseFileBlocks(assistantText);
    const newFileNames = Object.keys(newFiles);
    if (newFileNames.length === 0) {
      onProgress({ phase: "error", message: `Iteration ${iteration + 1}: LLM returned no parseable file blocks. This may indicate the model misunderstood the output format. Retrying...`, iteration: iteration + 1, tokensUsed: totalInputTokens + totalOutputTokens });
      iteration++;
      continue;
    }

    onProgress({ phase: "llm", message: `Iteration ${iteration + 1}: LLM produced ${newFileNames.length} file(s): ${newFileNames.join(", ")}. Writing to workspace...`, iteration: iteration + 1, tokensUsed: totalInputTokens + totalOutputTokens });

    currentFiles = await applyLlmFiles(workspaceDir, newFiles, (event) => {
      onProgress({ ...event, iteration: iteration + 1, tokensUsed: totalInputTokens + totalOutputTokens });
    });

    if (signal?.aborted) throw Object.assign(new Error("Cancelled"), { isAbort: true });
    try { await initWorkspace(workspaceDir, { signal, upgrade: true }); } catch {}

    onProgress({ phase: "validate", message: `Iteration ${iteration + 1}: Running terraform plan to validate changes...`, iteration: iteration + 1, tokensUsed: totalInputTokens + totalOutputTokens });

    const result = await plan(workspaceDir, { signal });
    planOutput = `${result.stdout}\n${result.stderr}`.trim();

    iteration++;

    if (result.clean) {
      onProgress({ phase: "done", message: `Clean plan achieved after ${iteration} iteration(s). Total tokens: ${(totalInputTokens + totalOutputTokens).toLocaleString()}.`, iteration, tokensUsed: totalInputTokens + totalOutputTokens });
      const finalFiles = await readWorkspaceFiles(workspaceDir);
      return { files: finalFiles, iterations: iteration, totalInputTokens, totalOutputTokens, clean: true };
    }

    const planSummary = (result.stdout || "").match(/Plan: .*/)?.[0] || "changes still pending";
    onProgress({ phase: "validate", message: `Iteration ${iteration}: Plan not clean yet (${planSummary}). ${maxIterations - iteration} attempt(s) remaining.`, iteration, tokensUsed: totalInputTokens + totalOutputTokens });
  }

  onProgress({ phase: "done", message: `Reached max iterations (${maxIterations}). Total tokens: ${(totalInputTokens + totalOutputTokens).toLocaleString()}. Manual review recommended.`, iteration, tokensUsed: totalInputTokens + totalOutputTokens });
  const finalFiles = await readWorkspaceFiles(workspaceDir);
  return { files: finalFiles, iterations: iteration, totalInputTokens, totalOutputTokens, clean: false, reason: "max_iterations" };
}

module.exports = { runAgentLoop, runSingleRefinement, parseFileBlocks };
