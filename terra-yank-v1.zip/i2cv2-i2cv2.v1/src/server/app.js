const express = require("express");
const path = require("path");
const { discoverResources, getAccountInfo, groupBy, categoryLabel } = require("./awsDiscovery");
const { parseTfstate, buildTfstateIndex, compareTfstate } = require("./tfstate");
const { buildImportArtifact, mapToTerraformImport } = require("./imports");
const { getUserSetting, setUserSetting, deleteUserSetting } = require("./db");
const {
  commitImportArtifact,
  commitWorkspaceFiles,
  createGitlabProject,
  listGitlabProjects,
  publicIntegration,
  upsertGitlabIntegration,
} = require("./gitlab");
const { slugify } = require("./utils");
const { createWorkspace, getTerraformVersion, initWorkspace, planGenerateConfig, plan, readWorkspaceFiles, writeWorkspaceFiles, destroyWorkspace, validateFilename } = require("./workspace");
const { runAgentLoop, runSingleRefinement } = require("./agent");
const { encrypt, decrypt } = require("./crypto");

const DEV_MODE = process.env.NODE_ENV === "development";
const DEV_USER = { id: "dev-user", name: "Dev User", email: "dev@localhost" };
const DEV_SESSION = { user: DEV_USER, session: { id: "dev-session", userId: DEV_USER.id } };

function asyncRoute(handler) {
  return async (req, res, next) => {
    try {
      await handler(req, res, next);
    } catch (error) {
      next(error);
    }
  };
}

function tfstateSummary(tfstate) {
  return {
    files: tfstate.files.map((f) => ({ name: f.name, uploadedAt: f.uploadedAt, resourceCount: f.parsed.length })),
    totalManagedResources: tfstate.files.reduce((sum, f) => sum + f.parsed.length, 0),
  };
}

function rebuildTfstateIndex(tfstate) {
  const all = tfstate.files.flatMap((f) => f.parsed);
  tfstate.index = all.length ? buildTfstateIndex(all) : null;
}

async function createApp({ auth } = {}) {
  const { toNodeHandler, fromNodeHeaders } = await import("better-auth/node");

  const app = express();
  const publicDir = path.join(__dirname, "..", "public");
  const tfstateByUser = new Map();
  function getUserTfstate(userId) {
    if (!tfstateByUser.has(userId)) tfstateByUser.set(userId, { files: [], index: null });
    return tfstateByUser.get(userId);
  }

  app.all("/api/auth/*splat", toNodeHandler(auth));

  app.use(express.json({ limit: "20mb" }));
  app.use((_req, res, next) => {
    res.setHeader("X-Content-Type-Options", "nosniff");
    res.setHeader("X-Frame-Options", "DENY");
    res.setHeader("Referrer-Policy", "strict-origin-when-cross-origin");
    res.setHeader("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; script-src 'self'");
    next();
  });
  app.use((req, res, next) => {
    const startedAt = Date.now();
    res.on("finish", () => {
      if (req.path.startsWith("/api/")) {
        console.log(`${req.method} ${req.path} ${res.statusCode} ${Date.now() - startedAt}ms`);
      }
    });
    next();
  });
  app.use(express.static(publicDir));

  app.get("/health", (_req, res) => {
    res.json({ ok: true, service: "i2cv2" });
  });

  app.get("/api/me", asyncRoute(async (req, res) => {
    if (DEV_MODE) return res.json({ user: DEV_USER });
    const session = await auth.api.getSession({
      headers: fromNodeHeaders(req.headers),
    });
    if (!session) return res.status(401).json({ error: "Not authenticated" });
    res.json({
      user: {
        name: session.user.name,
        email: session.user.email,
        image: session.user.image,
      },
    });
  }));

  app.use("/api", (req, res, next) => {
    if (req.path.startsWith("/auth/")) return next();
    if (DEV_MODE) {
      req.session = DEV_SESSION;
      return next();
    }
    (async () => {
      const session = await auth.api.getSession({
        headers: fromNodeHeaders(req.headers),
      });
      if (!session) return res.status(401).json({ error: "Not authenticated" });
      req.session = session;
      next();
    })().catch(next);
  });

  const VALID_AWS_REGION = /^[a-z]{2}-[a-z]+-\d{1,2}$/;
  const ALLOWED_MODELS = new Set(["bedrock.claude-sonnet-4-6", "bedrock.claude-haiku-4-5"]);

  function decryptAwsCredentials(aws) {
    if (!aws?.encryptedAccessKeyId) return undefined;
    return {
      accessKeyId: decrypt(aws.encryptedAccessKeyId),
      secretAccessKey: decrypt(aws.encryptedSecretAccessKey),
      ...(aws.encryptedSessionToken && { sessionToken: decrypt(aws.encryptedSessionToken) }),
    };
  }

  function awsEnvFromCredentials(credentials) {
    if (!credentials) return undefined;
    return {
      AWS_ACCESS_KEY_ID: credentials.accessKeyId,
      AWS_SECRET_ACCESS_KEY: credentials.secretAccessKey,
      ...(credentials.sessionToken && { AWS_SESSION_TOKEN: credentials.sessionToken }),
    };
  }

  app.get("/api/account", asyncRoute(async (req, res) => {
    const region = req.query.region || "ap-southeast-1";
    if (!VALID_AWS_REGION.test(region)) return res.status(400).json({ error: "Invalid AWS region." });
    const aws = await getUserSetting(req.session.user.id, "aws");
    const credentials = decryptAwsCredentials(aws);
    res.json(await getAccountInfo(region, credentials));
  }));

  app.post("/api/discovery/runs", asyncRoute(async (req, res) => {
    const region = req.body.region || "ap-southeast-1";
    if (!VALID_AWS_REGION.test(region)) return res.status(400).json({ error: "Invalid AWS region." });
    const aws = await getUserSetting(req.session.user.id, "aws");
    const credentials = decryptAwsCredentials(aws);
    const account = await getAccountInfo(region, credentials);
    const discovery = await discoverResources(region, credentials);

    const tfstate = getUserTfstate(req.session.user.id);
    if (!tfstate.index) {
      return res.json({ ...discovery, account, scannedAt: new Date().toISOString(), tfstateLoaded: false });
    }

    const allDiscovered = [
      ...(discovery.gcciGroups || []),
      ...(discovery.notTaggedCategoryGroups || []),
    ].flatMap((g) => g.resources);

    const { managed, unmanaged, staleStateResources, subResources } = compareTfstate(allDiscovered, tfstate.index, region);
    const managedArns = new Set(managed.map((r) => r.arn));
    const managedByArn = new Map(managed.map((r) => [r.arn, r.managedBy]));

    const filterGroups = (groups) => groups
      .map((g) => ({ ...g, resources: g.resources.filter((r) => !managedArns.has(r.arn)), count: 0 }))
      .map((g) => ({ ...g, count: g.resources.length }))
      .filter((g) => g.count > 0);

    const gcciGroups = (discovery.gcciGroups || []).map((g) => ({
      ...g,
      resources: g.resources.map((r) => {
        const managedBy = managedByArn.get(r.arn);
        return managedBy ? { ...r, managedBy } : r;
      }),
    }));
    const notTaggedCategoryGroups = filterGroups(discovery.notTaggedCategoryGroups || []);

    const managedCategoryGroups = groupBy(
      managed,
      (r) => r.category || "other/unknown",
      (r, key) => ({ category: key, label: categoryLabel(key), count: 0, services: {}, resources: [] }),
    );

    res.json({
      region: discovery.region,
      totalDiscovered: discovery.totalDiscovered,
      gcciTaggedCount: gcciGroups.reduce((sum, g) => sum + g.count, 0),
      notTaggedCount: notTaggedCategoryGroups.reduce((sum, g) => sum + g.count, 0),
      managedCount: managed.length,
      gcciGroups,
      notTaggedCategoryGroups,
      managedCategoryGroups,
      staleStateResources,
      subResources,
      tfstateLoaded: true,
      account,
      scannedAt: new Date().toISOString(),
    });
  }));

  app.post("/api/imports/generate", asyncRoute(async (req, res) => {
    const aws = await getUserSetting(req.session.user.id, "aws");
    const credentials = decryptAwsCredentials(aws);
    const artifact = await buildImportArtifact({
      selection: req.body.selection || [],
      region: req.body.region,
      account: req.body.account,
      credentials,
    });
    res.json(artifact);
  }));

  app.get("/api/projects", asyncRoute(async (req, res) => {
    const projects = await getUserSetting(req.session.user.id, "projects") || [];
    res.json({ projects });
  }));

  app.post("/api/projects", asyncRoute(async (req, res) => {
    const name = String(req.body.name || "").trim();
    if (!name) throw new Error("Project name is required.");

    const projects = await getUserSetting(req.session.user.id, "projects") || [];
    const id = req.body.id || slugify(name);
    const now = new Date().toISOString();

    const existing = projects.find((item) => item.id === id);
    if (existing) {
      existing.name = name;
      existing.description = req.body.description || "";
      existing.updatedAt = now;
      await setUserSetting(req.session.user.id, "projects", projects);
      return res.status(201).json(existing);
    }

    const project = { id, name, description: req.body.description || "", createdAt: now, updatedAt: now };
    projects.push(project);
    await setUserSetting(req.session.user.id, "projects", projects);
    res.status(201).json(project);
  }));

  app.get("/api/integrations", asyncRoute(async (req, res) => {
    const userId = req.session.user.id;
    const [aws, llm, gitlab] = await Promise.all([
      getUserSetting(userId, "aws"),
      getUserSetting(userId, "llm"),
      getUserSetting(userId, "gitlab"),
    ]);
    res.json({
      integrations: gitlab ? [publicIntegration(gitlab)] : [],
      gitlab: publicIntegration(gitlab),
      aws: { configured: Boolean(aws?.encryptedAccessKeyId) },
      llm: {
        configured: Boolean(llm?.encryptedApiKey),
        model: llm?.model || "bedrock.claude-sonnet-4-6",
        tokenBudget: llm?.tokenBudget || 100000,
      },
    });
  }));

  app.post("/api/integrations/gitlab", asyncRoute(async (req, res) => {
    const token = req.body.token;
    if (!token) return res.status(400).json({ error: "GitLab token is required." });
    const existing = await getUserSetting(req.session.user.id, "gitlab");
    const integration = await upsertGitlabIntegration(token, req.body, existing);
    await setUserSetting(req.session.user.id, "gitlab", integration);
    res.status(201).json(publicIntegration(integration));
  }));

  app.get("/api/integrations/gitlab/projects", asyncRoute(async (req, res) => {
    const gitlab = await getUserSetting(req.session.user.id, "gitlab");
    res.json(await listGitlabProjects(gitlab));
  }));

  app.post("/api/integrations/gitlab/projects/create", asyncRoute(async (req, res) => {
    const gitlab = await getUserSetting(req.session.user.id, "gitlab");
    const { name, namespaceId, visibility } = req.body;
    const project = await createGitlabProject({ gitlabSetting: gitlab, name, namespaceId, visibility });
    res.status(201).json(project);
  }));

  app.post("/api/gitlab/commit-import", asyncRoute(async (req, res) => {
    const gitlab = await getUserSetting(req.session.user.id, "gitlab");
    const { project: projectPath, branch, filePrefix, artifact } = req.body;
    const result = await commitImportArtifact({ gitlabSetting: gitlab, project: projectPath, branch, filePrefix, artifact });
    res.status(201).json(result);
  }));

  app.post("/api/credentials/aws", asyncRoute(async (req, res) => {
    const { accessKeyId, secretAccessKey, sessionToken } = req.body;
    if (!accessKeyId || !secretAccessKey) return res.status(400).json({ error: "Access key ID and secret access key are required." });
    await setUserSetting(req.session.user.id, "aws", {
      encryptedAccessKeyId: encrypt(accessKeyId),
      encryptedSecretAccessKey: encrypt(secretAccessKey),
      encryptedSessionToken: sessionToken ? encrypt(sessionToken) : null,
      configuredAt: new Date().toISOString(),
    });
    res.status(201).json({ configured: true });
  }));

  app.delete("/api/credentials/aws", asyncRoute(async (req, res) => {
    await deleteUserSetting(req.session.user.id, "aws");
    res.json({ configured: false });
  }));

  app.post("/api/credentials/llm", asyncRoute(async (req, res) => {
    const { apiKey, model, tokenBudget } = req.body;
    const existing = await getUserSetting(req.session.user.id, "llm");
    if (!apiKey && !existing?.encryptedApiKey) return res.status(400).json({ error: "API key is required." });
    const llm = {
      encryptedApiKey: apiKey ? encrypt(apiKey) : existing.encryptedApiKey,
      model: model || existing?.model || "bedrock.claude-sonnet-4-6",
      tokenBudget: tokenBudget || existing?.tokenBudget || 100000,
      configuredAt: new Date().toISOString(),
    };
    await setUserSetting(req.session.user.id, "llm", llm);
    res.status(201).json({ configured: true, model: llm.model, tokenBudget: llm.tokenBudget });
  }));

  app.delete("/api/credentials/llm", asyncRoute(async (req, res) => {
    await deleteUserSetting(req.session.user.id, "llm");
    res.json({ configured: false });
  }));

  app.post("/api/tfstate/upload", asyncRoute(async (req, res) => {
    const { name, content } = req.body;
    if (!name || !content) throw Object.assign(new Error("name and content are required."), { status: 400 });
    const tfstate = getUserTfstate(req.session.user.id);
    if (tfstate.files.length >= 20) throw Object.assign(new Error("Maximum 20 state files per user. Remove existing files before uploading more."), { status: 400 });
    const parsed = parseTfstate(content, name);
    tfstate.files.push({ name, uploadedAt: new Date().toISOString(), parsed });
    rebuildTfstateIndex(tfstate);
    res.status(201).json(tfstateSummary(tfstate));
  }));

  app.get("/api/tfstate", (req, res) => {
    res.json(tfstateSummary(getUserTfstate(req.session.user.id)));
  });

  app.delete("/api/tfstate/:index", (req, res) => {
    const tfstate = getUserTfstate(req.session.user.id);
    const idx = Number(req.params.index);
    if (idx < 0 || idx >= tfstate.files.length) throw Object.assign(new Error("Invalid file index."), { status: 400 });
    tfstate.files.splice(idx, 1);
    rebuildTfstateIndex(tfstate);
    res.json(tfstateSummary(tfstate));
  });

  app.delete("/api/tfstate", (req, res) => {
    const tfstate = getUserTfstate(req.session.user.id);
    tfstate.files.length = 0;
    tfstate.index = null;
    res.json(tfstateSummary(tfstate));
  });

  // --- Interactive workspace endpoints ---
  const workspaceByUser = new Map();
  function getUserWorkspace(userId) { return workspaceByUser.get(userId) || null; }

  function sseHeaders(res) {
    res.writeHead(200, { "Content-Type": "text/event-stream", "Cache-Control": "no-cache", Connection: "keep-alive" });
    return (data) => res.write(`data: ${JSON.stringify(data)}\n\n`);
  }

  app.post("/api/workspace", asyncRoute(async (req, res) => {
    const userId = req.session.user.id;
    if (workspaceByUser.has(userId)) return res.status(409).json({ error: "Workspace already exists. Close it first." });
    const { selection, region } = req.body;
    if (!selection || !selection.length) return res.status(400).json({ error: "No resources selected." });
    if (!region || !VALID_AWS_REGION.test(region)) return res.status(400).json({ error: "Invalid region." });

    const send = sseHeaders(res);
    const ac = new AbortController();
    let done = false;
    res.on("close", () => { if (!done) ac.abort(); });

    try {
      const aws = await getUserSetting(userId, "aws");
      const credentials = decryptAwsCredentials(aws);
      const awsEnv = awsEnvFromCredentials(credentials);

      send({ phase: "init", message: `Mapping ${selection.length} resource(s) to Terraform types...` });
      const unmapped = [];
      const mapped = selection.map((resource, idx) => {
        const m = mapToTerraformImport(resource);
        if (!m) { unmapped.push(resource.arn || resource.service || "unknown"); return null; }
        return { ...m, logicalName: `${m.tfType}_${slugify(resource.resourceType || resource.service)}_${idx + 1}` };
      }).filter(Boolean);
      if (unmapped.length) send({ phase: "init", message: `${unmapped.length} resource(s) could not be mapped.` });
      if (!mapped.length) { send({ phase: "error", message: "No resources could be mapped to Terraform types." }); return res.end(); }

      send({ phase: "init", message: `Creating Terraform workspace in ${region}...` });
      const ws = await createWorkspace({ region, resources: mapped });

      send({ phase: "init", message: "Running terraform init (downloading providers)..." });
      await initWorkspace(ws.dir, { signal: ac.signal, env: awsEnv });
      send({ phase: "init", message: "terraform init complete." });

      try {
        const ver = await getTerraformVersion();
        const providers = Object.entries(ver.providers).map(([k, v]) => `${k.split("/").pop()} ${v}`).join(", ");
        send({ phase: "init", message: `Terraform ${ver.terraform}${providers ? ` | Providers: ${providers}` : ""}` });
      } catch {}

      send({ phase: "plan", message: "Running terraform plan -generate-config-out..." });
      const genResult = await planGenerateConfig(ws.dir, { signal: ac.signal, env: awsEnv });
      if (!genResult.generated) {
        const hint = genResult.stderr ? `\n\nterraform output:\n${genResult.stderr.slice(0, 500)}` : "";
        send({ phase: "error", message: `terraform plan did not generate configuration.${hint}` });
        await destroyWorkspace(ws.dir);
        return res.end();
      }
      send({ phase: "plan", message: `Config generated (${genResult.generated.split("\n").length} lines).` });

      const files = await readWorkspaceFiles(ws.dir);
      workspaceByUser.set(userId, {
        id: ws.id, dir: ws.dir, region, awsEnv, createdAt: new Date().toISOString(),
        lastPlanOutput: null, lastPlanClean: null,
        totalInputTokens: 0, totalOutputTokens: 0, refinementCount: 0, busy: false,
      });

      send({ phase: "done", message: "Workspace ready.", files });
    } catch (err) {
      send({ phase: "error", message: err.message || "Workspace creation failed." });
    } finally {
      done = true;
      res.end();
    }
  }));

  app.get("/api/workspace", asyncRoute(async (req, res) => {
    const ws = getUserWorkspace(req.session.user.id);
    if (!ws) return res.status(404).json({ error: "No active workspace." });
    const files = await readWorkspaceFiles(ws.dir);
    res.json({ id: ws.id, region: ws.region, createdAt: ws.createdAt, files, lastPlanOutput: ws.lastPlanOutput, lastPlanClean: ws.lastPlanClean, totalInputTokens: ws.totalInputTokens, totalOutputTokens: ws.totalOutputTokens, refinementCount: ws.refinementCount, busy: ws.busy });
  }));

  app.put("/api/workspace/files", asyncRoute(async (req, res) => {
    const ws = getUserWorkspace(req.session.user.id);
    if (!ws) return res.status(404).json({ error: "No active workspace." });
    if (ws.busy) return res.status(409).json({ error: "Workspace is busy." });
    const { files } = req.body;
    if (!files || typeof files !== "object") return res.status(400).json({ error: "files object is required." });

    const protectedFiles = new Set(["main.tf", "imports.tf"]);
    const toWrite = {};
    for (const [name, content] of Object.entries(files)) {
      if (protectedFiles.has(name)) continue;
      validateFilename(name);
      toWrite[name] = content;
    }

    const existing = await readWorkspaceFiles(ws.dir);
    const fsLib = require("fs/promises");
    const pathLib = require("path");
    for (const name of Object.keys(existing)) {
      if (protectedFiles.has(name)) continue;
      if (!toWrite[name]) await fsLib.unlink(pathLib.join(ws.dir, name));
    }
    await writeWorkspaceFiles(ws.dir, toWrite);

    const updatedFiles = await readWorkspaceFiles(ws.dir);
    res.json({ files: updatedFiles });
  }));

  app.post("/api/workspace/plan", asyncRoute(async (req, res) => {
    const ws = getUserWorkspace(req.session.user.id);
    if (!ws) return res.status(404).json({ error: "No active workspace." });
    if (ws.busy) return res.status(409).json({ error: "Workspace is busy." });
    ws.busy = true;

    const send = sseHeaders(res);
    let done = false;
    const ac = new AbortController();
    res.on("close", () => { if (!done) ac.abort(); });

    try {
      send({ phase: "plan", message: "Running terraform plan..." });
      const result = await plan(ws.dir, { signal: ac.signal, env: ws.awsEnv });
      const planOutput = `${result.stdout}\n${result.stderr}`.trim();
      ws.lastPlanOutput = planOutput;
      ws.lastPlanClean = result.clean;
      const summary = (result.stdout || "").match(/Plan: .*/)?.[0] || (result.clean ? "No changes" : "see output");
      send({ phase: "done", message: `Plan complete (${summary}).`, stdout: result.stdout, stderr: result.stderr, clean: result.clean });
    } catch (err) {
      send({ phase: "error", message: err.message || "terraform plan failed." });
    } finally {
      ws.busy = false;
      done = true;
      res.end();
    }
  }));

  app.post("/api/workspace/refine", asyncRoute(async (req, res) => {
    const userId = req.session.user.id;
    const ws = getUserWorkspace(userId);
    if (!ws) return res.status(404).json({ error: "No active workspace." });
    if (ws.busy) return res.status(409).json({ error: "Workspace is busy." });

    const llm = await getUserSetting(userId, "llm");
    if (!llm?.encryptedApiKey) return res.status(400).json({ error: "LLM API key is not configured." });
    const apiKey = decrypt(llm.encryptedApiKey);
    const model = ALLOWED_MODELS.has(req.body.model) ? req.body.model : (llm.model || "bedrock.claude-sonnet-4-6");

    ws.busy = true;
    const send = sseHeaders(res);
    let done = false;
    const ac = new AbortController();
    res.on("close", () => { if (!done) ac.abort(); });

    try {
      const result = await runSingleRefinement({
        workspaceDir: ws.dir,
        apiKey,
        baseURL: process.env.ANTHROPIC_BASE_URL,
        model,
        customPrompt: req.body.prompt || null,
        signal: ac.signal,
        onProgress: send,
      });

      ws.lastPlanOutput = result.planOutput;
      ws.lastPlanClean = result.clean;
      ws.totalInputTokens += result.inputTokens;
      ws.totalOutputTokens += result.outputTokens;
      ws.refinementCount++;

      send({ phase: "done", message: result.clean ? "Refinement complete — clean plan." : "Refinement complete — plan still has changes.", files: result.files, clean: result.clean, inputTokens: result.inputTokens, outputTokens: result.outputTokens });
    } catch (err) {
      send({ phase: "error", message: err.message || "Refinement failed." });
    } finally {
      ws.busy = false;
      done = true;
      res.end();
    }
  }));

  app.delete("/api/workspace", asyncRoute(async (req, res) => {
    const userId = req.session.user.id;
    const ws = getUserWorkspace(userId);
    if (!ws) return res.status(404).json({ error: "No active workspace." });
    if (ws.busy) return res.status(409).json({ error: "Workspace is busy. Wait for the current operation to finish." });
    await destroyWorkspace(ws.dir);
    workspaceByUser.delete(userId);
    res.json({ ok: true });
  }));

  app.post("/api/workspace/commit", asyncRoute(async (req, res) => {
    const userId = req.session.user.id;
    const ws = getUserWorkspace(userId);
    if (!ws) return res.status(404).json({ error: "No active workspace." });
    const gitlab = await getUserSetting(userId, "gitlab");
    const { project, branch, filePrefix } = req.body;
    const files = await readWorkspaceFiles(ws.dir);
    const toCommit = {};
    for (const [name, content] of Object.entries(files)) {
      if (name !== "main.tf") toCommit[name] = content;
    }
    const result = await commitWorkspaceFiles({ gitlabSetting: gitlab, project, branch, filePrefix, files: toCommit });
    res.status(201).json(result);
  }));

  app.post("/api/import/generate", asyncRoute(async (req, res) => {
    const userId = req.session.user.id;
    const llm = await getUserSetting(userId, "llm");
    if (!llm?.encryptedApiKey) return res.status(400).json({ error: "LLM API key is not configured." });
    const apiKey = decrypt(llm.encryptedApiKey);

    const { selection, region } = req.body;
    const model = ALLOWED_MODELS.has(req.body.model) ? req.body.model : (llm.model || "bedrock.claude-sonnet-4-6");
    const maxIterations = Math.min(Number(req.body.maxIterations) || 10, 25);
    const tokenBudget = Math.min(Number(req.body.tokenBudget) || llm.tokenBudget || 100000, 500000);
    if (!selection || !selection.length) return res.status(400).json({ error: "No resources selected" });
    if (!region) return res.status(400).json({ error: "Region is required" });
    if (!VALID_AWS_REGION.test(region)) return res.status(400).json({ error: "Invalid AWS region." });

    res.writeHead(200, {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache",
      Connection: "keep-alive",
    });

    const send = (data) => {
      res.write(`data: ${JSON.stringify(data)}\n\n`);
    };

    const ac = new AbortController();
    let userDisconnected = false;
    let generationDone = false;
    res.on("close", () => {
      if (!generationDone) {
        console.log("Client disconnected during generation");
        userDisconnected = true;
        ac.abort();
      }
    });

    (async () => {
      let workspaceDir = null;
      try {
        send({ phase: "init", message: `Mapping ${selection.length} selected resource(s) to Terraform types...` });

        const unmapped = [];
        const mapped = selection.map((resource, idx) => {
          const m = mapToTerraformImport(resource);
          if (!m) {
            unmapped.push(resource.arn || resource.service || "unknown");
            return null;
          }
          return {
            ...m,
            logicalName: `${m.tfType}_${slugify(resource.resourceType || resource.service)}_${idx + 1}`,
          };
        }).filter(Boolean);

        if (unmapped.length) {
          send({ phase: "init", message: `${unmapped.length} resource(s) could not be mapped and will be skipped: ${unmapped.slice(0, 3).join(", ")}${unmapped.length > 3 ? ` (+${unmapped.length - 3} more)` : ""}` });
        }

        if (!mapped.length) {
          send({ phase: "error", message: "No selected resources could be mapped to Terraform types. Ensure the resources you selected have import support." });
          return res.end();
        }

        const tfTypes = [...new Set(mapped.map((r) => r.tfType))];
        send({ phase: "init", message: `Mapped ${mapped.length} resource(s) across ${tfTypes.length} Terraform type(s): ${tfTypes.slice(0, 5).join(", ")}${tfTypes.length > 5 ? ` (+${tfTypes.length - 5} more)` : ""}` });

        const aws = await getUserSetting(userId, "aws");
        const credentials = decryptAwsCredentials(aws);
        const awsEnv = awsEnvFromCredentials(credentials);

        send({ phase: "init", message: `Creating Terraform workspace in ${region}...` });
        const ws = await createWorkspace({ region, resources: mapped });
        workspaceDir = ws.dir;

        send({ phase: "init", message: "Running terraform init (downloading providers)..." });
        const initResult = await initWorkspace(ws.dir, { signal: ac.signal, env: awsEnv });
        if (initResult.stderr) {
          const warnings = initResult.stderr.split("\n").filter((l) => l.includes("Warning")).slice(0, 3);
          if (warnings.length) send({ phase: "init", message: `terraform init warnings: ${warnings.join("; ")}` });
        }
        send({ phase: "init", message: "terraform init complete." });

        try {
          const ver = await getTerraformVersion();
          const providers = Object.entries(ver.providers).map(([k, v]) => `${k.split("/").pop()} ${v}`).join(", ");
          send({ phase: "init", message: `Terraform ${ver.terraform}${providers ? ` | Providers: ${providers}` : ""}` });
        } catch {}

        send({ phase: "plan", message: "Running terraform plan -generate-config-out (this may take a minute)..." });
        const genResult = await planGenerateConfig(ws.dir, { signal: ac.signal, env: awsEnv });

        if (!genResult.generated) {
          const hint = genResult.stderr
            ? `\n\nterraform output:\n${genResult.stderr.slice(0, 500)}`
            : "";
          send({ phase: "error", message: `terraform plan did not generate any configuration. Check resource mappings and AWS credentials.${hint}` });
          return res.end();
        }

        send({ phase: "plan", message: `Initial config generated (${genResult.generated.split("\n").length} lines). Starting LLM refinement with ${model}...` });
        send({ phase: "plan", message: `Budget: ${tokenBudget.toLocaleString()} tokens, max ${maxIterations} iterations.` });

        const result = await runAgentLoop({
          workspaceDir: ws.dir,
          apiKey,
          baseURL: process.env.ANTHROPIC_BASE_URL,
          model,
          maxIterations,
          tokenBudget,
          signal: ac.signal,
          onProgress: send,
        });

        const fileCount = result.files ? Object.keys(result.files).filter((f) => f !== "main.tf").length : 0;
        send({
          phase: "done",
          message: result.clean
            ? `Import generation complete — clean plan achieved in ${result.iterations} iteration(s). ${fileCount} file(s) generated.`
            : `Import generation complete after ${result.iterations} iteration(s) (${result.reason}). ${fileCount} file(s) generated — manual review recommended.`,
          files: result.files,
          iterations: result.iterations,
          totalInputTokens: result.totalInputTokens,
          totalOutputTokens: result.totalOutputTokens,
          clean: result.clean,
        });
      } catch (err) {
        console.error("Import generation error:", err);
        console.error("userDisconnected:", userDisconnected, "| error name:", err.name, "| error code:", err.code);
        if (userDisconnected) {
          send({ phase: "cancelled", message: "Generation cancelled — client disconnected." });
        } else {
          const detail = err.stderr ? `\n\nterraform output:\n${err.stderr.slice(0, 500)}` : "";
          send({ phase: "error", message: `${err.message || "Unexpected error during import generation."}${detail}` });
        }
      } finally {
        generationDone = true;
        if (workspaceDir) await destroyWorkspace(workspaceDir);
        res.end();
      }
    })();
  }));

  app.get("/", (_req, res) => {
    res.sendFile(path.join(publicDir, "index.html"));
  });

  app.use((error, _req, res, _next) => {
    const status = error.status && error.status >= 400 ? error.status : 500;
    console.error(`API error ${status}: ${error.message}`);
    const safeMessage = status < 500
      ? (error.message || "Request failed")
      : "Unexpected server error";
    res.status(status).json({ error: safeMessage, status });
  });

  return app;
}

module.exports = { createApp };
