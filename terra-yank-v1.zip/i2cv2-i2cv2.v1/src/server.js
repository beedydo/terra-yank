const { createApp } = require("./server/app");
const { initDb } = require("./server/db");

const port = Number(process.env.PORT || 4000);

(async () => {
  const { auth } = await import("./server/auth.mjs");
  const { getMigrations } = await import("better-auth/db/migration");
  const { runMigrations } = await getMigrations(auth.options);
  await runMigrations();
  await initDb();
  const app = await createApp({ auth });
  app.listen(port, () => {
    console.log(`i2cv2 server listening on port ${port}`);
    if (process.env.NODE_ENV === "development") console.log("⚠ DEV MODE: authentication is bypassed");
  });
})();
